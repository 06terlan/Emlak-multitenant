<?php

header('Location: http://ulviemlak.az/ht/pro2/public/admin/login');
