# Emlak multi tenant

**Framework : Laravel** <br/>
**version : 5.***