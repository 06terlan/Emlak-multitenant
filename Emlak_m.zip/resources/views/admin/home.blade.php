@extends('admin.masterpage')

@section('content')

@endsection

@section('css')

@endsection

@section('scripts')

@endsection
