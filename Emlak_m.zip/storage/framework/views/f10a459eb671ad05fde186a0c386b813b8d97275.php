<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('admin.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">

        <div class="col-md-12 col-sm-12 col-xs-12">

            <div class="x_panel">

                <div class="x_title">

                    <h2>Elan</h2>

                    <ul class="nav navbar-right panel_toolbox">

                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>

                    </ul>

                    <div class="clearfix"></div>

                </div>

                <div class="x_content">

                    <br>

                    <form autocomplete="off" class="form-horizontal form-label-left" novalidate=""  method="post">

                        <div class="item form-group">

                            <label class="control-label col-md-3 col-sm-3 col-xs-3">Header:</label>

                            <div class="col-md-6 col-sm-6 col-xs-3" style="line-height: 36px;">

                                <?php echo $announcement->header; ?>


                            </div>

                        </div>

                        <div class="item form-group">

                            <label class="control-label col-md-3 col-sm-3 col-xs-3">Link:</label>

                            <div class="col-md-6 col-sm-6 col-xs-3" style="line-height: 36px;">

                                <a href="<?php echo e($announcement->link); ?>">Link</a>

                            </div>

                        </div>

                        <div class="item form-group">

                            <label class="control-label col-md-3 col-sm-3 col-xs-3">Kategoria:</label>

                            <div class="col-md-6 col-sm-6 col-xs-3" style="line-height: 36px;">

                                <?php echo e($announcement->getAnnouncementType()); ?>


                            </div>

                        </div>

                        <div class="item form-group">

                            <label class="control-label col-md-3 col-sm-3 col-xs-3">Elanın Tipi:</label>

                            <div class="col-md-6 col-sm-6 col-xs-3" style="line-height: 36px;">

                                <?php echo e($announcement->getBuldingType()); ?>


                            </div>

                        </div>

                        <div class="item form-group">

                            <label class="control-label col-md-3 col-sm-3 col-xs-3">Tarix:</label>

                            <div class="col-md-6 col-sm-6 col-xs-3" style="line-height: 36px;">

                                <?php echo e(\App\Library\Date::d($announcement->date, "d-m-Y")); ?>


                            </div>

                        </div>

                        <div class="item form-group">

                            <label class="control-label col-md-3 col-sm-3 col-xs-3">Dəyəri:</label>

                            <div class="col-md-6 col-sm-6 col-xs-3" style="line-height: 36px;">

                                <?php echo e($announcement->amount); ?>


                            </div>

                        </div>



                        <div class="item form-group">

                            <label class="control-label col-md-3 col-sm-3 col-xs-3">Nömrə:</label>

                            <div class="col-md-6 col-sm-6 col-xs-3" style="line-height: 36px;">

                                <?php $__currentLoopData = $announcement['numbers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typeK => $num): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <div class="numb">
                                        <?php echo e($num['number']); ?>

                                        <?php echo \App\Library\MyHelper::getMakler($num['pure_number']); ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>

                        </div>


                        <div class="item form-group">

                            <label class="control-label col-md-3 col-sm-3 col-xs-3">Sahibkar:</label>

                            <div class="col-md-6 col-sm-6 col-xs-3" style="line-height: 36px;">

                                <?php echo e($announcement->owner); ?>


                            </div>

                        </div>





                        <div class="item form-group">

                            <label class="control-label col-md-3 col-sm-3 col-xs-3">Content:</label>

                            <div class="col-md-6 col-sm-6 col-xs-3" style="line-height: 36px;">

                                <?php echo $announcement->content; ?>


                            </div>

                        </div>





                </div>

                <div class="ln_solid"></div>

                <div class="form-group">

                    <div class="col-md-9 col-sm-6 col-xs-12 col-md-offset-3">

                        <a class="btn btn-default" href="<?php echo e(url()->previous()); ?>" type="reset"><i class="fa fa-arrow-circle-left"></i> Back</a>

                        <?php if(\App\Library\MyHelper::has_priv("announcement", \App\Library\MyClass::PRIV_CAN_ADD)): ?>
                            <a href="<?php echo e(route('announcement_delete',['id'=>$announcement->id])); ?>" class="btn btn-danger deleteAction"><i class="fa fa-trash"></i> Delete</a>
                            <a href="<?php echo e(route('announcement_pro_add_from',['id'=>$announcement->id])); ?>" class="btn btn-success"><i class="fa fa-check"></i> Fərdiyə əlavə et</a>
                        <?php endif; ?>
                    </div>

                </div>

                </form>

            </div>

        </div>

    </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.masterpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>