<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('admin.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>

<body class="nav-md">
<div class="container body">
    <div class="main_container">
        <?php echo $__env->make('admin.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- page content -->
        <div class="right_col" role="main">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <!-- /page content -->

        <footer>
            <div class="pull-right">
                 Created by <a href="">A.Terlan</a>
            </div>
            <div class="clearfix"></div>
        </footer>
    </div>
</div>

<?php echo $__env->make('admin.foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>
