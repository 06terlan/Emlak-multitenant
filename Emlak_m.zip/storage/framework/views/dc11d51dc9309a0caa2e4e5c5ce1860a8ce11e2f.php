<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>İstifadəçi</h2>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <br>
                    <form autocomplete="off" class="form-horizontal form-label-left" novalidate=""  method="post" action="<?php echo e(url('admin/users/addEdit/'.$id)); ?>">
                        <div class="item form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Name
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input required="" name="name" data-validate-length-range="5,20" type="text" class="form-control has-feedback-left" placeholder="Name" value="<?php echo e($User['firstname']); ?>">
                                <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
                            </div>
                        </div>
                        <div class="item form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Surname
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input name="surname" data-validate-length-range="5,20" type="text" class="form-control has-feedback-left" placeholder="Surname" value="<?php echo e($User['surname']); ?>">
                                <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
                            </div>
                        </div>
                        <div class="item form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Login
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" value="<?php echo e($User['login']); ?>" name="login" placeholder="Login" required="required" class="form-control col-md-7 col-xs-12">
                            </div>
                        </div>
                        <div class="item form-group">
                            <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Email</label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input autocomplete="off" required="" name="email" type="email" class="form-control has-feedback-left" value="<?php echo e($User['email']); ?>" placeholder="Email">
                                <span class="fa fa-envelope form-control-feedback left" aria-hidden="true"></span>
                            </div>
                        </div>
                        <div class="item form-group">
                            <label for="password" class="control-label col-md-3">Password </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input autocomplete="off" <?php if($id == 0): ?> <?php echo e('required=""'); ?> <?php endif; ?> type="password" placeholder="Password" name="password" data-validate-length="5,20" class="form-control col-md-7 col-xs-12">
                            </div>
                        </div>
                        <div class="item form-group">
                            <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Role</label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <select class="form-control" name="group_id" required="">
                                    <?php $__currentLoopData = \App\Models\Group::realData()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($type['id']); ?>" <?php echo e($type['id'] == $User['group_id']? 'selected':''); ?>> <?php echo e($type['group_name']); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <?php if( Auth::user()->group->super_admin == 1 ): ?>
                            <div class="item form-group">
                                <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Tenant</label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <select class="form-control" name="tenant" required="">
                                        <?php $__currentLoopData = \App\Models\Tenant::realTenants()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($type['id']); ?>" <?php echo e($type['id'] == $User['tenant_id']? 'selected':''); ?>> <?php echo e($type['company_name']); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        <?php endif; ?>

                        <div class="ln_solid"></div>
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <div class="form-group">
                            <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                <button type="submit" class="btn btn-success">Save</button>
                                <a class="btn btn-default" href="<?php echo e(url('admin/users/')); ?>" type="reset">Cancel</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <?php echo Html::style('admin/assets/vendors/iCheck/skins/flat/green.css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo Html::script('admin/assets/vendors/validator/validator.js'); ?>

    <?php echo Html::script('admin/assets/vendors/iCheck/icheck.min.js'); ?>


    <script type="text/javascript">
        $("select[name=role]").val(<?php echo e($User['role']); ?>);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.masterpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>