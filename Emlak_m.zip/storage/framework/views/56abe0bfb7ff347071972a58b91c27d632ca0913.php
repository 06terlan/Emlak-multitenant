<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Admin panel</title>

<!-- Bootstrap -->
<?php echo Html::style('admin/assets/vendors/bootstrap/dist/css/bootstrap.min.css'); ?>

<!-- Font Awesome -->
<?php echo Html::style('admin/assets/vendors/font-awesome/css/font-awesome.min.css'); ?>

<!-- NProgress -->
<?php echo Html::style('admin/assets/vendors/nprogress/nprogress.css'); ?>

<!-- bootstrap-progressbar -->
<?php echo Html::style('admin/assets/vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css'); ?>

<!-- Custom Theme Style -->
<?php echo Html::style('admin/assets/build/css/custom.min.css'); ?>

<!-- PNotify -->
<?php echo Html::style('admin/assets/vendors/pnotify/dist/pnotify.css'); ?>

<?php echo Html::style('admin/assets/vendors/pnotify/dist/pnotify.buttons.css'); ?>

<?php echo Html::style('admin/assets/vendors/pnotify/dist/pnotify.nonblock.css'); ?>


<?php echo $__env->yieldContent('css'); ?>