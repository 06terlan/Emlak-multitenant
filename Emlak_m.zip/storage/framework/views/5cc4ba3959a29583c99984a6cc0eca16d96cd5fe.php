<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Makler</h2>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <br>
                    <form autocomplete="off" class="form-horizontal form-label-left" novalidate=""  method="post" action="<?php echo e(route('msk_group_add_edit', ['group' => $id])); ?>">
                        <div class="item form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Group Name
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input required="" name="group_name" data-validate-length-range="1,20" type="text" class="form-control" placeholder="Group Name" value="<?php echo e($group['group_name']); ?>">
                            </div>
                        </div>
                        <div class="item form-group">
                            <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Görəcəyi kategorialar</label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <?php $__currentLoopData = \App\Library\MyClass::$announcementTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typeK => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="checkbox" name="available_types[]" value="<?php echo e($typeK); ?>" <?php echo e($id > 0 && in_array($typeK,json_decode($group->available_types)) ? 'checked' : ''); ?> class="flat" /> <?php echo e($type); ?> <br/>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="item form-group">
                            <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Görəcəyi elanın tipləri</label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <?php $__currentLoopData = \App\Library\MyClass::$buldingType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typeK => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="checkbox" name="available_building_types[]" value="<?php echo e($typeK); ?>" <?php echo e($id > 0 && in_array($typeK,json_decode($group->available_building_types)) ? 'checked' : ''); ?> class="flat" /> <?php echo e($type); ?> <br/>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="item form-group">
                            <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Modullar</label>
                            <div class="col-md-9 col-sm-12 col-xs-12">
                                <?php $__currentLoopData = \App\Library\MyClass::$modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typeK => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if( isset($type['child']) ): ?>
                                        <div class="col-md-12">
                                            <label class="col-md-7"><i class="<?php echo e($type['icon']); ?>"></i> <?php echo e($typeK); ?>:</label>
                                            <?php $__currentLoopData = $type['child']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $K => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if( $t['priv'] > 3 && ($id == 0 || $group->super_admin != 1) ): ?> <?php continue; ?>; <?php endif; ?>
                                                <div class="col-md-12" style="padding-left: 50px">
                                                    <label class="col-md-5"><?php echo e($t['name']); ?>:</label>
                                                    <div class="col-md-7">
                                                        Görmür <input type="radio" class="flat" name="available_modules[<?php echo e($t['route']); ?>]" id="<?php echo e($t['route']); ?>" value="1" <?php echo e($id >0 && $group->getModulePriv($t['route']) == 1 ? 'checked' : ''); ?> />
                                                        &nbsp;&nbsp;&nbsp;&nbsp; Görür <input type="radio" class="flat" name="available_modules[<?php echo e($t['route']); ?>]" id="<?php echo e($t['route']); ?>" value="2" <?php echo e($id >0 && $group->getModulePriv($t['route']) == 2 ? 'checked' : ''); ?> />
                                                        &nbsp;&nbsp;&nbsp;&nbsp; Əlavə edir <input type="radio" class="flat" name="available_modules[<?php echo e($t['route']); ?>]" id="<?php echo e($t['route']); ?>" value="3" <?php echo e($id >0 && $group->getModulePriv($t['route']) == 3 ? 'checked' : ''); ?> />
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php else: ?>
                                        <?php if( $type['priv'] > 3 && ($id == 0 || $group->super_admin != 1) ): ?> <?php continue; ?>; <?php endif; ?>
                                        <div class="col-md-12">
                                            <label class="col-md-5"><i class="<?php echo e($type['icon']); ?>"></i> <?php echo e($type['name']); ?>:</label>
                                            <div class="col-md-7">
                                                Görmür <input type="radio" class="flat" name="available_modules[<?php echo e($type['route']); ?>]" id="<?php echo e($type['route']); ?>" value="1" <?php echo e($id >0 && $group->getModulePriv($type['route']) == 1 ? 'checked' : ''); ?> />
                                                &nbsp;&nbsp;&nbsp;&nbsp; Görür <input type="radio" class="flat" name="available_modules[<?php echo e($type['route']); ?>]" id="<?php echo e($type['route']); ?>" value="2" <?php echo e($id >0 && $group->getModulePriv($type['route']) == 2 ? 'checked' : ''); ?> />
                                                &nbsp;&nbsp;&nbsp;&nbsp; Əlavə edir <input type="radio" class="flat" name="available_modules[<?php echo e($type['route']); ?>]" id="<?php echo e($type['route']); ?>" value="3" <?php echo e($id >0 && $group->getModulePriv($type['route']) == 3 ? 'checked' : ''); ?> />
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <div class="ln_solid"></div>
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <div class="form-group">
                            <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                <button type="submit" class="btn btn-success">Save</button>
                                <a class="btn btn-default" href="<?php echo e(redirect()->back()->getTargetUrl()); ?>" type="reset">Cancel</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- iCheck -->
    <?php echo Html::style('admin/assets/vendors/iCheck/skins/flat/green.css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <!-- validator -->
    <?php echo Html::script('admin/assets/vendors/validator/validator.js'); ?>

    <!-- jquery.inputmask -->
    <?php echo Html::script('admin/assets/vendors/jquery.inputmask/jquery.inputmask.bundle.min.js'); ?>

    <!-- iCheck -->
    <?php echo Html::script('admin/assets/vendors/iCheck/icheck.min.js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.masterpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>