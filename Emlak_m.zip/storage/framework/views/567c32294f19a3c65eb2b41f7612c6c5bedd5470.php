<!-- jQuery -->
<?php echo Html::script('admin/assets/vendors/jquery/dist/jquery.min.js'); ?>

<!-- Bootstrap -->
<?php echo Html::script('admin/assets/vendors/bootstrap/dist/js/bootstrap.min.js'); ?>

<!-- NProgress -->
<?php echo Html::script('admin/assets/vendors/nprogress/nprogress.js'); ?>

<!-- bootstrap-progressbar -->
<?php echo Html::script('admin/assets/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js'); ?>

<!-- PNotify -->
<?php echo Html::script('admin/assets/vendors/pnotify/dist/pnotify.js'); ?>

<?php echo Html::script('admin/assets/vendors/pnotify/dist/pnotify.buttons.js'); ?>

<?php echo Html::script('admin/assets/vendors/pnotify/dist/pnotify.nonblock.js'); ?>

<!-- Custom Theme Scripts -->
<?php echo Html::script('admin/assets/build/js/custom.min.js'); ?>

<?php echo $__env->yieldContent('scripts'); ?>

<script>
    var lastId = <?php echo e(App\Models\Announcement::todayAnnouncements()->first() != null ? App\Models\Announcement::todayAnnouncements()->first()->id : 0); ?>;
    var notficationCount = <?php echo e(\App\Library\MyClass::INFO_COUNT); ?>;
    var _token = "<?php echo e(csrf_token()); ?>";
    var link = "<?php echo e(route('getLastAnnouncementAjax')); ?>";
</script>
<?php echo Html::script('admin/js/apper.js?1'); ?>

