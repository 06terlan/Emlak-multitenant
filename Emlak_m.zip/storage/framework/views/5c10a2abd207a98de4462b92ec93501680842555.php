<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php if( \App\Library\MyHelper::has_priv('users', \App\Library\MyClass::PRIV_CAN_ADD) ): ?>
        <a href="<?php echo e(route('user_add_edit',['user' => 0])); ?>" class="btn btn-round btn-success btn_add_standart"><i class="fa fa-plus"></i> Add</a>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>İstifadəçilər</h2>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <form method="get" action="" class="formFinder">
                        <input type="hidden" name="page" value="<?php echo e($request->get("page",1)); ?>">
                        <table class="table table-striped formFinder">
                            <thead>
                                <tr>
                                    <th width="40px">#</th>
                                    <th>Full Name</th>
                                    <th>Email</th>
                                    <th>Login</th>
                                    <th>Group</th>
                                    <?php if( Auth::user()->group->super_admin == 1 ): ?>
                                        <th>Tenant</th>
                                    <?php endif; ?>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <thead>
                                <tr>
                                    <th></th>
                                    <th><input class="form-control formFind" name="fullname" value="<?php echo e($request->get("fullname")); ?>" placeholder="Full Name"></th>
                                    <th><input class="form-control formFind" name="email" value="<?php echo e($request->get("email")); ?>" placeholder="Email"></th>
                                    <th><input class="form-control formFind" name="login" value="<?php echo e($request->get("login")); ?>" placeholder="Login"></th>
                                    <th>
                                        <select class="form-control formFind" name="group_id">
                                            <option></option>
                                            <?php $__currentLoopData = \App\Models\Group::realData()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($type['id']); ?>" <?php echo e($type['id'] == $request->get("group_id") ? 'selected':''); ?>> <?php echo e($type['group_name']); ?> </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </th>
                                    <?php if( Auth::user()->group->super_admin == 1 ): ?>
                                        <th>
                                            <select class="form-control formFind" name="tenant">
                                                <option></option>
                                                <?php $__currentLoopData = \App\Models\Tenant::realTenants()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($type['id']); ?>" <?php echo e($type['id'] == $request->get("tenant") ? 'selected':''); ?>> <?php echo e($type['company_name']); ?> </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </th>
                                    <?php endif; ?>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $Users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($Users->perPage() * ($Users->currentPage() - 1) + $loop->iteration); ?></td>
                                        <td><?php echo e($user->fullname()); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->login); ?></td>
                                        <td><?php echo e($user->group->group_name); ?></td>
                                        <?php if( Auth::user()->group->super_admin == 1 ): ?>
                                            <td><?php echo e($user->tenant->company_name); ?></td>
                                        <?php endif; ?>
                                        <th>
                                            <?php if( $user->group->super_admin != 1 && \App\Library\MyHelper::has_priv('users', \App\Library\MyClass::PRIV_CAN_ADD)): ?>
                                                <a style="width:25px;" href="<?php echo e(route('user_add_edit',['user' => $user->id])); ?>" data-toggle="tooltip" data-original-title="Edit" class="btn btn-primary btn-xs"><i class="fa fa-edit"></i></a>
                                            <?php endif; ?>
                                            <?php if( Auth::user()->id != $user->id && $user->group->super_admin != 1 && \App\Library\MyHelper::has_priv('users', \App\Library\MyClass::PRIV_CAN_ADD)): ?>
                                                <a style="width:25px;" href="<?php echo e(route('user_delete',['user' => $user->id])); ?>" data-toggle="tooltip" data-original-title="Delete" class="btn btn-danger btn-xs deleteAction"><i class="fa fa-trash"></i></a>
                                            <?php endif; ?>
                                        </th>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </form>
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <?php echo e($Users->links('admin.pagination', ['paginator' => $Users])); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
    <?php echo Html::style('admin/assets/vendors/jquery-confirm-master/css/jquery-confirm.css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo Html::script('admin/assets/vendors/jquery-confirm-master/js/jquery-confirm.js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.masterpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>