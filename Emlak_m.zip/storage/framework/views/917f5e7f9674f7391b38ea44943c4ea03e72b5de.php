<?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        <a href="<?php echo e(route('announcement_info', $announcement['id'])); ?>">
            <span>
                <span><?php echo e(str_limit(strip_tags($announcement['header']), 25, '...')); ?></span>
                <span class="time"><?php echo e(App\Library\Date::diffForHumans( $announcement['created_at'] )); ?> ago</span>
            </span>
            <span class="message">
                <?php echo e(str_limit(strip_tags($announcement['content']), 40, '...')); ?>

            </span>
        </a>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>