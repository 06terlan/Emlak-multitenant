<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('admin.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <?php if( \App\Library\MyHelper::has_priv("announcement_pro", \App\Library\MyClass::PRIV_CAN_ADD) ): ?>
        <a href="<?php echo e(route('announcement_insert',['announcement' => 0])); ?>" class="btn btn-round btn-success btn_add_standart"><i class="fa fa-plus"></i> Add</a>
    <?php endif; ?>


    <div class="row">

        <div class="col-md-12 col-sm-12 col-xs-12">

            <div class="x_panel">

                <div class="x_title">

                    <h2>Elanlar</h2>

                    <ul class="nav navbar-right panel_toolbox">

                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>

                    </ul>

                    <div class="clearfix"></div>

                </div>

                <div class="x_content">

                    <form method="get" action="" class="formFinder">

                        <input type="hidden" name="page" value="<?php echo e($request->get("page",1)); ?>">

                        <table class="table table-striped">

                            <thead>

                                <tr>

                                    <th>#</th>

                                    <th>Başlıq</th>

                                    <th>Content</th>

                                    <th>Tipi</th>

                                    <th>Qiymət</th>

                                    <th>Tarix</th>

                                    <th>Əlavə edən</th>

                                    <th>Status</th>

                                    <th>Əməliyyatlar</th>

                                </tr>

                            </thead>

                            <thead>

                                <tr>

                                    <th data-toggle="tooltip" data-original-title="Maklersiz elanlar">
                                        <input type="checkbox" name="no_makler" <?php echo e($request->get("no_makler") ? 'checked' : ''); ?> class="flat formFind" />
                                    </th>

                                    <th><input class="form-control formFind" name="header" value="<?php echo e($request->get("header")); ?>" placeholder="Başlıq"></th>

                                    <th><input class="form-control formFind" name="content" value="<?php echo e($request->get("content")); ?>" placeholder="Content"></th>

                                    <th>
                                        <select class="form-control formFind" name="type">
                                            <option></option>
                                            <?php $__currentLoopData = \App\Library\MyClass::$announcementTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typeK => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($typeK); ?>" <?php echo e($typeK == $request->get("type") ? 'selected':''); ?>> <?php echo e($type); ?> </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </th>

                                    <th><input class="form-control formFind" name="amount" value="<?php echo e($request->get("amount")); ?>" placeholder="Qiymət"></th>

                                    <th><input class="form-control formFind" name="date" value="<?php echo e($request->get("date")); ?>" placeholder="Tarix"></th>

                                    <th><input class="form-control formFind" name="user" value="<?php echo e($request->get("user")); ?>" placeholder="Əlavə edən"></th>

                                    <th>
                                        <select class="form-control formFind" name="status">
                                            <option></option>
                                            <?php $__currentLoopData = \App\Library\MyClass::$buttonStatus2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typeK => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($typeK); ?>" <?php echo e($typeK == \Illuminate\Support\Facades\Input::get('status')? 'selected':''); ?>> <?php echo e($type); ?> </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </th>

                                    <th></th>

                                </tr>

                            </thead>

                            <tbody>

                                <?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <!-- <tr style="<?php echo e($announcement->buldingType==2?'background-color:#9fd4ef':'background-color:red'); ?>"> -->

                                        <tr>

                                        <td><?php echo e($announcements->perPage() * ($announcements->currentPage() - 1) + $loop->iteration); ?> <?php echo $announcement['is_makler'] == 1?"<i style='color:red;font-size:20px' class='fa fa-child' data-toggle='tooltip' data-original-title='Makler'></i>":''; ?></td>

                                        <td><?php echo e($announcement->header); ?></td>

                                        <td><?php echo e($announcement->getShortContent()); ?></td>

                                        <td><?php echo e($announcement->getAnnouncementType()); ?></td>

                                        <td><?php echo e($announcement->amount); ?></td>

                                        <td><?php echo e(App\Library\Date::d($announcement->date,'d-m-Y')); ?></td>

                                        <td><?php echo e($announcement->author->fullname()); ?></td>

                                        <td><?php echo $announcement->getStatus(); ?></td>

                                        <th>
                                            <a style="width: 24px;" href="<?php echo e(route('announcement_pro_info',['announcement'=>$announcement->id])); ?>" data-toggle="tooltip" data-original-title="İnfo" class="btn btn-info btn-xs"><i class="fa fa-info-circle"></i></a>

                                            <?php if( \App\Library\MyHelper::has_priv("announcement_pro", \App\Library\MyClass::PRIV_CAN_ADD) ): ?>
                                                <a style="width: 24px;" href="<?php echo e(route('announcement_insert',['announcement'=>$announcement->id])); ?>" data-toggle="tooltip" data-original-title="Edit" class="btn btn-primary btn-xs"><i class="fa fa-edit"></i></a>

                                                <a style="width: 24px;" href="<?php echo e(route('announcement_pro_delete',['announcement'=>$announcement->id])); ?>" data-toggle="tooltip" data-original-title="Delete" class="btn btn-danger btn-xs deleteAction"><i class="fa fa-trash"></i></a>

                                                <a style="width: 24px;" href="<?php echo e(route('announcement_pro_status',['announcement'=>$announcement->id])); ?>" data-toggle="tooltip" data-original-title="<?php echo e(isset(\App\Library\MyClass::$buttonStatus[$announcement->status]) ? \App\Library\MyClass::$buttonStatus[$announcement->status] : '-'); ?>" class="btn btn-success btn-xs"><i class="fa fa-thumb-tack"></i></a>
                                            <?php endif; ?>
                                        </th>

                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>

                        </table>

                    </form>

                    <div class="row">

                        <div class="col-md-12 text-center">

                            <?php echo e($announcements->links('admin.pagination', ['paginator' => $announcements])); ?>


                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('css'); ?>

    
    <?php echo Html::style('admin/assets/vendors/jquery-confirm-master/css/jquery-confirm.css'); ?>


    
    <?php echo Html::style('admin/assets/vendors/iCheck/skins/flat/green.css'); ?>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
    
    <?php echo Html::script('admin/assets/vendors/jquery-confirm-master/js/jquery-confirm.js'); ?>\

    
    <?php echo Html::script('admin/assets/vendors/iCheck/icheck.min.js'); ?>


    <script>
        $(function () {
            $("input.flat.formFind").on('ifChanged', function (e) {
                $(this).parents("form:eq(0)").submit();
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.masterpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>